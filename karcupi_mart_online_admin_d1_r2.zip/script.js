const menuBtn=document.getElementById("menuBtn");const navLinks=document.getElementById("navLinks");menuBtn.onclick=()=>navLinks.classList.toggle("active");document.querySelectorAll(".nav-links a").forEach(a=>a.onclick=()=>navLinks.classList.remove("active"));function openImage(src){document.getElementById("modalImg").src=src;document.getElementById("modal").style.display="flex"}function closeImage(){document.getElementById("modal").style.display="none"}document.getElementById("contactForm").addEventListener("submit",e=>{
  e.preventDefault();
  const name=document.getElementById("customerName").value.trim();
  const phone=document.getElementById("customerPhone").value.trim();
  const service=document.getElementById("service").value;
  const quantity=document.getElementById("quantity").value.trim() || "উল্লেখ করা হয়নি";
  const details=document.getElementById("details").value.trim();
  const productName=document.getElementById("productName").value.trim() || "উল্লেখ করা হয়নি";
  const message=[
    "আসসালামু আলাইকুম। কারচুপি মার্টে নতুন অর্ডার/জিজ্ঞাসা।",
    "",
    "নাম: "+name,
    "মোবাইল: "+phone,
    "সেবা: "+service,
    "পণ্যের নাম: "+productName,
    "পরিমাণ: "+quantity,
    "বিস্তারিত: "+details
  ].join("\n");
  const url="https://wa.me/8801753628097?text="+encodeURIComponent(message);
  window.open(url,"_blank");
  e.target.reset();
});

document.querySelectorAll(".order-btn").forEach(btn=>btn.addEventListener("click",()=>{
  const product=btn.dataset.product;
  const price=btn.dataset.price;
  const message=[
    "আসসালামু আলাইকুম। কারচুপি মার্টে একটি পণ্যের অর্ডার করতে চাই।",
    "",
    "পণ্য: "+product,
    "দাম: "+price,
    "",
    "দয়া করে পণ্যের সাইজ, ডিজাইন, পরিমাণ ও ডেলিভারি সম্পর্কে জানাবেন।"
  ].join("\n");
  window.open("https://wa.me/8801753628097?text="+encodeURIComponent(message),"_blank");
}));


(async()=>{const g=document.getElementById("productGrid");if(!g)return;try{const r=await fetch("/api/products");const ps=await r.json();const e=x=>String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));g.innerHTML=ps.map(p=>`<article class="product-card"><div class="product-img"><img src="${e(p.image_url||"images/product-custom.svg")}" alt="${e(p.name)}"></div><div class="product-body"><span class="product-tag">${e(p.category)}</span><h3>${e(p.name)}</h3><p class="price">${e(p.price)}</p><p>${e(p.description)}</p><button class="btn gold order-btn" data-product="${e(p.name)}" data-price="${e(p.price)}">🛒 অর্ডার করুন</button></div></article>`).join("")||"<p>এখনও কোনো পণ্য নেই।</p>"}catch{g.innerHTML="<p>পণ্য লোড করতে সমস্যা হয়েছে।</p>"}})();
