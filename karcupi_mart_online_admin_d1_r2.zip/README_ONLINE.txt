কারচুপি মার্ট — Online Admin (Cloudflare Pages Functions + D1 + R2)

এই ZIP-এ মূল website, secure Admin Panel, Pages Functions API, D1 schema এবং R2 image upload রয়েছে।

Cloudflare সেটআপ:
1. D1 database তৈরি করুন: karcupi-mart-db
2. schema.sql চালিয়ে products table তৈরি করুন।
3. R2 bucket তৈরি করুন: karcupi-mart-images
4. wrangler.toml-এ আপনার D1 database_id বসান।
5. Cloudflare Secret হিসেবে ADMIN_PASSWORD সেট করুন।
6. Wrangler দিয়ে Pages Functions সহ deploy করুন; সাধারণ Dashboard drag-and-drop Direct Upload Functions deploy করার জন্য যথেষ্ট নয়।
7. সাইটের /admin.html খুলে password দিয়ে লগইন করুন।

প্রতিবার নতুন পণ্য যোগ করতে ZIP আপলোড করতে হবে না। Admin Panel থেকেই Add/Edit/Delete করা যাবে এবং website-এর সব visitor একই D1 data দেখবে।
