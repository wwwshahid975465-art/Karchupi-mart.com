কারচুপি মার্ট — Admin Panel version

ব্যবহার:
1. index.html = মূল ওয়েবসাইট
2. admin.html = Admin Panel
3. Admin Panel থেকে ছবি, নাম, দাম, ক্যাটাগরি ও বর্ণনা দিয়ে পণ্য যোগ/এডিট/ডিলিট করুন।
4. একই ব্রাউজারে index.html খুললে নতুন পণ্য দেখা যাবে।
5. Backup দিয়ে পণ্যের JSON সংরক্ষণ এবং Restore দিয়ে ফিরিয়ে আনা যাবে।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
এই সংস্করণে Local Storage ব্যবহার করা হয়েছে। তাই Admin Panel-এর পরিবর্তন শুধু সেই একই browser/device-এ থাকে। Cloudflare-এ সাইট প্রকাশ করলেই সব visitor-এর browser-এ নতুন পণ্য ছড়িয়ে যাবে না।

সবার জন্য online product management করতে Cloudflare Pages Functions + D1 database + R2 image storage (বা অন্য backend) সংযোগ করতে হবে। Cloudflare-এর বর্তমান docs অনুযায়ী Pages Functions-এর সঙ্গে D1 ও R2 bindings ব্যবহার করা যায়; তবে Dashboard Direct Upload দিয়ে Functions deploy করা যায় না।
